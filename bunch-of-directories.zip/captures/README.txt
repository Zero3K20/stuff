Placeholder capture listing
