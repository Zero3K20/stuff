Placeholder logs listing
